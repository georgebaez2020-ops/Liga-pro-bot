"""Bot descriptivo para Czech Liga Pro. Sin cuotas ni recomendaciones de apuestas."""
import asyncio
import json
import logging
import os
import re
import sqlite3
from datetime import datetime
from zoneinfo import ZoneInfo

from playwright.async_api import async_playwright
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

COL = ZoneInfo('America/Bogota')
PRAGA = ZoneInfo('Europe/Prague')
BASE = 'https://tt.league-pro.com/en/tournaments'
MAX_TORNEOS = int(os.getenv('MAX_TORNEOS', '30'))
DB_PATH = os.getenv('DATABASE_PATH', 'data/liga_pro.sqlite3')
LOG = logging.getLogger('liga-pro')

JS_FILAS = '''() => Array.from(document.querySelectorAll('.c-tournament-group-item')).map(fila =>
    Array.from(fila.querySelectorAll(':scope > div')).map(celda => {
        const a = celda.querySelector('a');
        return (a ? a.innerText : celda.innerText).trim();
    })
)'''


def db():
    os.makedirs(os.path.dirname(DB_PATH) or '.', exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.execute('''CREATE TABLE IF NOT EXISTS snapshots (
        id INTEGER PRIMARY KEY AUTOINCREMENT, captured_at TEXT NOT NULL,
        tournament_id TEXT NOT NULL, group_no INTEGER NOT NULL,
        player TEXT NOT NULL, rating TEXT, position TEXT, results_json TEXT,
        sets TEXT, balls TEXT, points TEXT, place TEXT,
        UNIQUE(captured_at,tournament_id,group_no,player))''')
    con.execute('CREATE INDEX IF NOT EXISTS idx_snap_player ON snapshots(player, captured_at)')
    return con


def url_lista(dia_col, status=''):
    y, m, d = (int(x) for x in dia_col.split('-'))
    ini = datetime(y, m, d, 0, 0, tzinfo=COL).astimezone(PRAGA).date()
    fin = datetime(y, m, d, 23, 59, tzinfo=COL).astimezone(PRAGA).date()
    url = f'{BASE}?date_from={ini}&date_to={fin}'
    return url + (f'&status={status}' if status else '')


def armar_grupos(filas):
    grupos, actual, tam = [], [], 0
    for c in filas:
        n = len(c) - 7
        if n < 2:
            continue
        if not actual:
            tam = n + 1  # n rivales + el propio jugador
        actual.append({'pos': c[0], 'jugador': c[1], 'rating': c[2],
                       'resultados': c[3:3+n], 'sets': c[3+n],
                       'balls': c[4+n], 'points': c[5+n], 'place': c[6+n]})
        if len(actual) == tam:
            grupos.append(actual)
            actual = []
    if actual:
        grupos.append(actual)
    return grupos


async def extraer_datos():
    dia = datetime.now(COL).strftime('%Y-%m-%d')
    status = os.getenv('STATUS', '').strip()
    ids = [x.strip().rstrip('/').split('/')[-1]
           for x in os.getenv('TORNEOS', '').split(',') if x.strip()]
    resultado = {'generado': datetime.now(COL).isoformat(timespec='seconds'),
                 'dia_colombia': dia, 'torneos': {}}
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True, args=['--no-sandbox', '--disable-dev-shm-usage'])
        page = await browser.new_page()
        if not ids:
            await page.goto(url_lista(dia, status), wait_until='domcontentloaded', timeout=60000)
            await page.wait_for_timeout(2500)
            html = await page.content()
            ids = sorted(set(re.findall(r'/en/tournaments/([0-9]+)', html)))
        for tid in ids[:MAX_TORNEOS]:
            link = f'{BASE}/{tid}'
            try:
                await page.goto(link, wait_until='domcontentloaded', timeout=60000)
                await page.wait_for_selector('.c-tournament-group-item', timeout=18000)
                rows = await page.evaluate(JS_FILAS)
                resultado['torneos'][tid] = {'url': link, 'grupos': armar_grupos(rows)}
            except Exception as exc:
                resultado['torneos'][tid] = {'url': link, 'grupos': [], 'aviso': type(exc).__name__}
        await browser.close()
    return resultado


def guardar(resultado):
    con = db()
    captured = resultado['generado']
    count = 0
    for tid, torneo in resultado['torneos'].items():
        for gi, grupo in enumerate(torneo.get('grupos', []), 1):
            for j in grupo:
                con.execute('''INSERT OR IGNORE INTO snapshots
                    (captured_at,tournament_id,group_no,player,rating,position,results_json,sets,balls,points,place)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?)''',
                    (captured, tid, gi, j['jugador'], j.get('rating'), j.get('pos'),
                     json.dumps(j.get('resultados', []), ensure_ascii=False), j.get('sets'),
                     j.get('balls'), j.get('points'), j.get('place')))
                count += 1
    con.commit()
    con.close()
    os.makedirs('salida', exist_ok=True)
    with open('salida/tablas.json', 'w', encoding='utf-8') as f:
        json.dump(resultado, f, ensure_ascii=False, indent=2)
    return count


async def actualizar(context=None):
    LOG.info('Iniciando captura de Czech Liga Pro')
    datos = await extraer_datos()
    filas = guardar(datos)
    LOG.info('Captura terminada: %s torneos, %s filas procesadas', len(datos['torneos']), filas)
    return datos


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        '🏓 *Czech Liga Pro — Analizador*\n\n'
        'Uso:\n/actualizar — consultar torneos actuales\n'
        '/torneos — ver última captura\n'
        '/jugador NOMBRE — consultar registros guardados\n'
        '/ayuda — explicar los datos', parse_mode='Markdown')


async def cmd_ayuda(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        'El bot recopila tablas publicadas en tt.league-pro.com y conserva capturas históricas. '
        'Por ahora informa posiciones, rating y resultados tal como aparecen en la tabla. '
        'No calcula H2H ni presión competitiva hasta validar una fuente oficial de partidos individuales; '
        'tampoco usa cuotas, AiScore ni recomendaciones de apuestas.')


async def cmd_actualizar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = await update.message.reply_text('Consultando la página oficial…')
    try:
        data = await actualizar()
        total = sum(len(t.get('grupos', [])) for t in data['torneos'].values())
        await msg.edit_text(f"Actualización terminada. Torneos consultados: {len(data['torneos'])}. Grupos con datos: {total}.")
    except Exception as exc:
        LOG.exception('Error actualizando')
        await msg.edit_text(f'No se pudo actualizar ({type(exc).__name__}). Intenta de nuevo más tarde.')


async def cmd_torneos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        with open('salida/tablas.json', encoding='utf-8') as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        await update.message.reply_text('Aún no hay captura. Ejecuta /actualizar.')
        return
    lines = [f"Captura: {data.get('generado', 's/d')}"]
    for tid, t in data.get('torneos', {}).items():
        n = sum(len(g) for g in t.get('grupos', []))
        lines.append(f"• Torneo {tid}: {len(t.get('grupos', []))} grupos, {n} jugadores" if not t.get('aviso') else f"• Torneo {tid}: {t['aviso']}")
    await update.message.reply_text('\n'.join(lines)[:4000])


async def cmd_jugador(update: Update, context: ContextTypes.DEFAULT_TYPE):
    nombre = ' '.join(context.args).strip()
    if not nombre:
        await update.message.reply_text('Escribe el nombre. Ejemplo: /jugador Schneider Pavel')
        return
    con = db()
    rows = con.execute('''SELECT captured_at,tournament_id,position,rating,place,results_json
        FROM snapshots WHERE player LIKE ? ORDER BY captured_at DESC LIMIT 10''', (f'%{nombre}%',)).fetchall()
    con.close()
    if not rows:
        await update.message.reply_text('No encuentro registros guardados para ese nombre. Prueba con el nombre completo.')
        return
    lines = [f'Registros recientes de {nombre}:']
    for when, tid, pos, rating, place, _ in rows:
        lines.append(f'• {when[:16]} | torneo {tid} | puesto {pos or "s/d"} | rating {rating or "s/d"} | lugar {place or "s/d"}')
    await update.message.reply_text('\n'.join(lines)[:4000])


async def job_actualizacion(context: ContextTypes.DEFAULT_TYPE):
    try:
        await actualizar()
    except Exception:
        LOG.exception('Falló la actualización programada')


def main():
    logging.basicConfig(level=os.getenv('LOG_LEVEL', 'INFO'))
    token = os.getenv('TELEGRAM_BOT_TOKEN') or os.getenv('TELEGRAM_TOKEN')
    if not token:
        raise RuntimeError('Falta TELEGRAM_BOT_TOKEN en las variables de entorno de Render.')
    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler('start', cmd_start))
    app.add_handler(CommandHandler('ayuda', cmd_ayuda))
    app.add_handler(CommandHandler('actualizar', cmd_actualizar))
    app.add_handler(CommandHandler('torneos', cmd_torneos))
    app.add_handler(CommandHandler('jugador', cmd_jugador))
    if app.job_queue:
        app.job_queue.run_repeating(job_actualizacion, interval=1800, first=15)
    app.run_polling(drop_pending_updates=True)


if __name__ == '__main__':
    main()
