# Czech Liga Pro — Telegram Analyzer

Bot de Telegram que consulta las tablas de `tt.league-pro.com`, conserva capturas en SQLite y permite consultar torneos y registros de jugadores.

## Comandos
- `/start` y `/ayuda`
- `/actualizar`
- `/torneos`
- `/jugador Nombre Apellido`

## Variables de entorno
- `TELEGRAM_BOT_TOKEN`: token del bot de Telegram (obligatorio).
- `DATABASE_PATH`: ruta SQLite; Render usa `/var/data/liga_pro.sqlite3`.
- `TORNEOS`: opcional, IDs o enlaces separados por coma.
- `DIA`: opcional, fecha de consulta en formato `AAAA-MM-DD`.
- `STATUS`: opcional, filtro de estado de la web.
- `MAX_TORNEOS`: máximo de torneos por consulta (30 por defecto).

El bot realiza una captura al iniciar y luego cada 30 minutos. También puede actualizarse manualmente.

## Alcance y límites de esta versión
Esta versión elimina por completo AiScore, cuotas y pronósticos basados en cuotas. Los datos históricos guardados son capturas de las tablas oficiales; no equivalen todavía a un historial completo de partidos individuales. El H2H, el análisis de puntos críticos y los patrones de respuesta bajo presión quedan pendientes de validar contra datos oficiales partido a partido. No se deben inferir esos indicadores a partir de la posición o el rating.

## Despliegue
1. Configura `TELEGRAM_BOT_TOKEN` en Render como variable secreta.
2. Conserva el disco persistente `/var/data` definido en `render.yaml`.
3. Despliega el servicio como Worker.
4. En Telegram, envía `/start` y luego `/actualizar`.
